# Discovery-based FedShop

This variant turns FedShop into a decentralised marketplace where nobody knows the whole federation. It keeps FedShop's data and queries, but changes what the engine knows and how the rest can be found.

- **Classical members** (`discovery.classical`, half of the vendors and half of the rating sites by default) are SPARQL endpoints given to the engine up front, exactly as in FedShop. They are the engine's way in.
- **Discovered members** are the other vendors and rating sites. The engine is not told about them; it has to find them through links.
- **Reviewer storages** (`discovery.reviewers`). Every reviewer has a storage of their own. Reviewers are people, not institutions: there are many of them and they come and go, so nobody registers them.

## Storages

Every member and every reviewer is a storage on the web, and every IRI is served at its original FedShop IRI (apart from the reviewers, see below):

- one document per subject (`http://www.vendor4.fr/Product12`);
- a storage root at the namespace IRI (`http://www.vendor4.fr/`) with `ldp:contains` for every document. A member's root also names the member's SPARQL endpoint with `void:sparqlEndpoint`: FedShop's own virtual Virtuoso endpoint, which answers for this member only. Reviewer storages have no endpoint.

Classical and discovered members look the same on the web. The only difference is that the engine knows the classical endpoints up front.

## How members find each other: links between copies

FedShop members share no data, only global BSBM IRIs. Each member keeps a local copy of every product, producer and feature it deals with, linked with `owl:sameAs` to the global IRI. The variant adds links between those copies (`discovery.links`):

| From | To | Setting | Meaning |
|---|---|---|---|
| a shop's copy | review sites' copies | `reviews` (default 2) | reviews of this product / brand / feature |
| a review site's copy | shops' copies | `where_to_buy` (default 3) | where to buy it |
| a review site's copy | other review sites' copies | `also_reviewed` (default 0) | also reviewed at |

- Shops never link to other shops.
- Each value is a number of peers per copy, or `all`.
- Peers are drawn at random per copy (`links.seed`), so no member knows every holder and finding all of them can take several hops.
- `links.kinds` (default: Product, Producer, ProductFeature) sets which copies get links.
  - Product links serve most queries.
  - Producer links serve queries where members meet only at a shared producer (q13).
  - Feature links serve queries where they meet at a shared feature (q01, q04, q05, q14).

The links are `rdfs:seeAlso` triples. No FedShop query uses that predicate, so they change no answer. A traversal engine has to follow them as a chosen link predicate next to cMatch.

Global IRI pages, which list every member holding a copy, can be turned on with `pages.kinds`. They are an index, so they are off by default and kept only as a baseline to compare against.

## Reviewers

- **The profile moves.** Each reviewer's profile (name, country, ...) moves out of the rating site into one document at `http://www.reviewer<k>.fr/me`, listed by the storage root `http://www.reviewer<k>.fr/`.
- **The reviews stay.** They remain at the rating site, and their `rev:reviewer` triple points at the new IRI. That triple is the only way to a reviewer.
- **The rating sites' endpoints no longer know their reviewers.** Any query that needs a profile has to follow the link out (q07, q08, q15).

## The container update

`fedshop-discovery update-container` changes the Virtuoso container of the variant's batch (`docker-bsbm-virtuoso-<batch+1>`):

- each reviewer storage becomes its own named graph;
- the rating sites' graphs lose their reviewer profiles, and their `rev:reviewer` triples are renamed;
- the links are inserted into the member graphs.

Endpoints, documents, reference results and the analysis then all see the same data.

- The update is idempotent.
- `update-container --restore` undoes both changes. Standard FedShop runs on that container (query generation, evaluation) need it restored first.
- `build-workload` and `check` refuse to run when the container disagrees with `split.json` and `links.tsv`.

## Pipeline

All commands take the usual FedShop config. `config_small.yaml` and `config.yaml` have a `discovery:` section.

`config_small.yaml` uses a product pool of 200 instead of 20,000, so that a product has about one offer and about five reviews, as in the full config. With 20,000, members hardly ever hold the same product and links cannot connect them.

```bash
CONFIG=experiments/bsbm/snakefile/config_small.yaml

# 1. Data and ingestion, as in the quickstart
uv run fedshop generate data $CONFIG
uv run fedshop ingest $CONFIG

# 2. Query instances whose constants are picked on the full federation (the last batch),
#    instead of FedShop's batch 0. Run this before update-container (or after --restore).
uv run fedshop generate queries $CONFIG --config="value_selection_batch=1"   # = n_batch - 1

# 3. Split, draw the links, update the container, build the web, select the workload
uv run fedshop-discovery all $CONFIG

# 4. Serve the web (keeps running; restart it after every build-web)
uv run fedshop-discovery serve $CONFIG
```

`fedshop-discovery all` runs `split`, `update-container`, `build-web` and `build-workload`, which can also be run one by one. `fedshop-discovery check $CONFIG query.sparql` analyses any single query.

The analysis queries the Virtuoso container of the variant's batch and starts it if needed. The storage roots point at that container's member endpoints, so keep it running while an engine is evaluated.

## Reaching the web

The server on `discovery.web.port` (8899) accepts three request forms:

| Client | How |
|---|---|
| curl, Java (`-Dhttp.proxyHost=localhost -Dhttp.proxyPort=8899`) | forward proxy: `GET http://www.vendor4.fr/Product12` |
| Comunica (`--httpProxy http://localhost:8899/`) | prefix proxy: `GET /http://www.vendor4.fr/Product12` |
| anything else | `Host: www.vendor4.fr` with an `/etc/hosts` entry pointing to the server |

- **Headers:** every document carries `Link: <storage root>; rel="http://www.w3.org/ns/pim/space#storage"`.
- **Unknown IRIs:** IRIs of unknown storages return 404.
- **Pass-through:** other requests to local hosts (the SPARQL endpoints) are passed through (`web.passthrough: local`). Anything else, such as the country IRIs in FedShop's data, returns 404, so a run never reaches the internet.
- **Counters:** `GET http://localhost:8899/_stats` reports request and byte counts per document kind, and `/_reset` resets them.

Node.js engines (Comunica) need `node -r experiments/bsbm/discovery/no-keepalive.js` (or `NODE_OPTIONS="--require <path>"`) when they query the Virtuoso endpoints. Virtuoso keeps at most 10 idle connections and silently drops the rest, and Node's `fetch` then fails with `fetch failed` when it reuses one. The preload sends every request with `Connection: close`. Raising Virtuoso's `MaxKeepAlives` instead crashed Virtuoso under load.

## Outputs (`experiments/bsbm/benchmark/discovery/`)

| File | Content |
|---|---|
| `split.json` | classical and discovered members (name → namespace IRI); reviewer storages (name → root, IRI, rating site, original IRI) |
| `links.tsv` | every link: global IRI, member, its copy, peer member, the peer's copy |
| `web.sqlite` | every document and storage root (and pages, if enabled); plus `holders` (which member holds a copy of each global IRI) |
| `sources/classical-endpoints.tsv`, `sources/classical-fedx.ttl` | the classical sources, also as a FedX config |
| `sources/storage-roots.txt` | the roots of all discovered storages (for analysis only; an engine must discover them) |
| `workload/<query>/instance_<i>/` | `injected.sparql`, `results.csv` (reference answer over the full federation), `reachable.csv` (the part of it reachable through the links), `seeds.txt`, `analysis.json` |
| `workload-summary.csv` | one row per analysed instance, selected or not |

## How instances are selected

Every candidate is run over the full federation with each triple pattern wrapped in its own `GRAPH ?gN`, so each derivation shows which storage supplied each pattern. From that:

- **category**:
  - `classical-only`: every solution can be found from the classical members alone;
  - `discovery-only`: no derivation uses a classical member;
  - `hybrid-union`: some solutions need discovered storages, but no single solution mixes the two parts;
  - `hybrid-join`: at least one solution joins a classical member and a discovered storage.
- **reachable solutions**: reaching starts at the classical members. In each round, every global IRI the query binds leads further. Those are its constants and the terms of patterns supplied by reached storages. From every reached member's copy of such an IRI, the links are followed hop by hop to other members' copies. A local IRI inside a discovered storage (a review's `rev:reviewer`) leads into that storage. With pages on, a page also links to the members it lists.
  - `reachable_share` is the reachable part of the answer.
  - `link_rounds` and `storages_reached_best_case` show how far an engine has to go.
  - `solutions_needing_reviewers` and `reviewer_storages_needed` count the reviewer hops.

FedShop's own instances are kept when at least one solution needs a discovered storage and is reachable.

Instances whose answer no classical member contributes to and links to can't be reached from the federation at all. They are dropped: in this setting discovery extends the federation, it doesn't replace it.

The templates in `queries/` are:

| Template | Asks for |
|---|---|
| `q13` | offers for products of the same producer |
| `q14` | reviews of products sharing a feature |
| `q15` | reviews by reviewers from the country of a vendor offering the product |

Their instances are anchored on a product held by a classical member for which the template has an answer. They are kept when at least one reachable solution needs discovery and joins a classical member with a discovered storage.
