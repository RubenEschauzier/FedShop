"""Discovery-based variant of FedShop: a decentralised marketplace.

Part of the federation stays classical (members are known SPARQL endpoints). The rest is only
discoverable on the web, as storages: the other vendors and rating sites (one document per subject,
a storage root that names the member's SPARQL endpoint), and every reviewer in a storage of their
own (documents only). Pages for global BSBM IRIs link to the member storages holding a local copy.
See experiments/bsbm/discovery/README.md.
"""
