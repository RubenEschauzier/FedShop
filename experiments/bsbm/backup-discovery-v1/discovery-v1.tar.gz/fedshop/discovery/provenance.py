"""Per-solution provenance and reachability of a query over the split federation.

The query is rewritten so that every triple pattern sits in its own `GRAPH ?gN { ... }` and run
without ORDER BY/LIMIT over the full federation. Each derivation then tells which member supplied
each triple pattern, which is enough to decide:

- whether a classical-only engine can find the solution (all patterns from classical members);
- whether the solution mixes classical and discovered members;
- whether an engine following links can reach every storage it needs. Reaching starts at the
  classical members (and the storages of the query's constant local IRIs). In each round, the global
  IRIs the query binds (its constants, and the terms of patterns supplied by reached storages) lead
  further: from every reached member's copy of such an IRI, its seeAlso links are followed hop by
  hop to the copies at other members. A local IRI inside a discovered storage (e.g. a review's
  `rev:reviewer`) leads into that storage. With the pages baseline on, a global IRI's page also
  links to the members listed on it.
  A reached member's copy of a bound global IRI counts as found: the engine gets it from that
  member's endpoint or documents through the query's `owl:sameAs` patterns.
"""
import re
from collections import defaultdict

from rdflib.plugins.sparql.algebra import translateQuery, traverse
from rdflib.plugins.sparql.parser import parseQuery

from .common import global_kind, member_root, sparql_csv

TERM = re.compile(r'<[^>]*>|"(?:[^"\\]|\\.)*"(?:\^\^<[^>]*>|\^\^\S+|@[\w-]+)?|\S+')
SKIP = re.compile(r"^\s*(PREFIX|SELECT|WHERE|FILTER|ORDER|LIMIT|OFFSET|#|\}|\{|UNION)", re.I)


def _expand(term, prefixes):
    if term.startswith("<") or term.startswith("?") or term.startswith('"') or term[0].isdigit():
        return term
    if ":" in term:
        pfx, local = term.split(":", 1)
        if pfx in prefixes:
            return f"<{prefixes[pfx]}{local}>"
    return term


def _count_patterns(query):
    count = [0]

    def visit(node):
        if getattr(node, "name", None) == "BGP":
            count[0] += len(node.triples)
    traverse(translateQuery(parseQuery(query)).algebra, visitPre=visit)
    return count[0]


def rewrite(query):
    """Wrap each triple pattern of a one-pattern-per-line query in its own GRAPH clause.

    Returns (provenance_query, projection, patterns) where patterns[i] = (s, p, o) for ?g{i+1}.
    """
    prefixes = dict(re.findall(r"PREFIX\s+(\w*):\s*<([^>]*)>", query, re.I))
    patterns, out = [], []

    def wrap(text):
        terms = [_expand(t, prefixes) for t in TERM.findall(text.strip().rstrip(".").strip())]
        if len(terms) != 3:
            raise ValueError(f"Cannot parse triple pattern: {text!r}")
        patterns.append(tuple(terms))
        return f"GRAPH ?g{len(patterns)} {{ {' '.join(terms)} . }}"

    for line in query.splitlines():
        s = line.strip()
        m = re.match(r"^OPTIONAL\s*\{\s*(.+?)\s*\.?\s*\}\s*$", s, re.I)
        if m:
            out.append(f"OPTIONAL {{ {wrap(m.group(1))} }}")
        elif s and not SKIP.match(s) and not re.match(r"^OPTIONAL\s*\{\s*$", s, re.I) and len(TERM.findall(s.rstrip("."))) == 3 and s.endswith("."):
            out.append(wrap(s))
        else:
            out.append(line)

    expected = _count_patterns(query)
    if expected != len(patterns):
        raise ValueError(f"Rewrote {len(patterns)} triple patterns but the query has {expected}")

    q = "\n".join(out)
    projection = re.search(r"SELECT\s+(?:DISTINCT\s+|REDUCED\s+)?(.*?)\s+WHERE", q, re.S | re.I).group(1).split()
    q = re.sub(r"SELECT\s+(?:DISTINCT\s+|REDUCED\s+)?.*?\s+WHERE", "SELECT DISTINCT * WHERE", q, count=1, flags=re.S | re.I)
    # Drop solution modifiers (FedShop writes e.g. "OFFSET 0 LIMIT 10" on one line): provenance needs every solution
    q = re.sub(r"^\s*(ORDER\s+BY|LIMIT|OFFSET|##).*$", "", q, flags=re.M | re.I)
    return q, [v.lstrip("?") for v in projection], patterns


def derivations(endpoint, query, max_rows):
    """Run the provenance query. Returns (projection, patterns, rows) or raises if too large."""
    pquery, projection, patterns = rewrite(query)
    rows = sparql_csv(endpoint, pquery + f"\nLIMIT {max_rows + 1}")
    if len(rows) > max_rows:
        raise OverflowError(f"more than {max_rows} derivations")
    return projection, patterns, rows


def constant_globals(patterns):
    return sorted({t[1:-1] for tp in patterns for t in tp if t.startswith("<") and global_kind(t[1:-1])})


def constant_locals(patterns):
    """Constant local IRIs (e.g. an offer in q11/q12); dereferencing one leads into its storage."""
    return sorted({t[1:-1] for tp in patterns for t in tp if t.startswith("<") and member_root(t[1:-1])})


class Analyzer:
    """Reachability over the split, given which members hold a local copy of each global IRI."""

    def __init__(self, split, holders, pages, links=None):
        self.links = links or {}          # global IRI -> member -> peer members its copy links to
        self.classical = set(split["classical"].values())
        self.reviewers = {r["root"] for r in (split.get("reviewers") or {}).values()}
        self.discovered = set(split["discovered"].values()) | self.reviewers
        self.holders = holders            # global IRI -> set of member namespaces
        self.kinds = set(pages["kinds"])
        listed = set(split["discovered"].values()) | (self.classical if pages.get("include_classical") else set())
        self.listed = listed

    def page_links(self, iri):
        """Members a page links to; empty if the kind has no pages."""
        if global_kind(iri) not in self.kinds:
            return set()
        return self.holders.get(iri, set()) & self.listed

    def seeds(self, patterns):
        """Constant IRIs worth dereferencing: global IRIs with a page, and IRIs inside a discovered storage."""
        return ([g for g in constant_globals(patterns) if self.page_links(g)]
                + [c for c in constant_locals(patterns) if member_root(c) in self.discovered])

    def seed_links(self, seed):
        root = member_root(seed)
        return {root} if root else self.page_links(seed)

    def follow(self, iri, reached):
        """Members whose copies of iri are reached by following seeAlso links from reached copies."""
        adj = self.links.get(iri)
        if not adj:
            return set()
        seen = {m for m in self.holders.get(iri, ()) if m in reached}
        frontier = set(seen)
        while frontier:
            frontier = set().union(*(adj.get(m, set()) for m in frontier)) - seen
            seen |= frontier
        return seen - reached

    def reach(self, patterns, row):
        """Storages reachable for one derivation, and the number of link rounds needed."""
        reached = set(self.classical)
        for seed in self.seeds(patterns):
            reached |= self.seed_links(seed)
        constants = constant_globals(patterns)
        rounds = 1
        while True:
            values = set(constants)
            for i, tp in enumerate(patterns, start=1):
                graph = row.get(f"g{i}")
                if graph and graph in reached:
                    values |= {row.get(t[1:]) if t.startswith("?") else t[1:-1] for t in tp if t[0] in "?<"}
            new = set()
            for value in filter(None, values):
                if global_kind(value):
                    new |= (self.page_links(value) | self.follow(value, reached)) - reached
                elif member_root(value) in self.discovered - reached:
                    new.add(member_root(value))
            if not new:
                return reached, rounds
            reached |= new
            rounds += 1

    def analyse(self, projection, patterns, rows):
        solutions = defaultdict(list)
        for row in rows:
            solutions[tuple(row.get(v, "") for v in projection)].append(row)

        stats = defaultdict(int)
        storages, needed, reached_any, max_rounds = set(), set(), set(), 0
        self.reachable = set()
        for key, derivs in solutions.items():
            classical_only = mixed = discoverable = reached_mixed = False
            sol_needed = None
            for row in derivs:
                graphs = {row[f"g{i}"] for i in range(1, len(patterns) + 1) if row.get(f"g{i}")}
                storages |= graphs
                found = graphs & self.discovered
                classical_only |= not found
                mixed |= bool(found) and bool(graphs & self.classical)
                reached, rounds = self.reach(patterns, row)
                if graphs <= reached:
                    discoverable = True
                    reached_mixed |= bool(found) and bool(graphs & self.classical)
                    max_rounds = max(max_rounds, rounds)
                    reached_any |= (reached & self.discovered)
                if sol_needed is None or len(found) < len(sol_needed):
                    sol_needed = found
            stats["classical_only"] += classical_only
            stats["needs_discovery"] += not classical_only
            stats["mixed"] += mixed
            stats["discoverable"] += discoverable
            if discoverable:
                self.reachable.add(key)
            stats["reachable_needing_discovery"] += discoverable and not classical_only
            stats["reachable_mixed"] += reached_mixed and not classical_only
            if not classical_only:
                needed |= sol_needed
                stats["needs_reviewers"] += bool(sol_needed & self.reviewers)

        n = len(solutions)
        if n == 0:
            category = "empty"
        elif stats["needs_discovery"] == 0:
            category = "classical-only"
        elif stats["mixed"] > 0:
            category = "hybrid-join"
        elif stats["classical_only"] > 0:
            category = "hybrid-union"
        else:
            category = "discovery-only"
        seeds = self.seeds(patterns)
        return {
            "category": category,
            "solutions": n,
            "derivations": len(rows),
            "classical_only_solutions": stats["classical_only"],
            "solutions_needing_discovery": stats["needs_discovery"],
            "solutions_needing_reviewers": stats["needs_reviewers"],
            "mixed_solutions": stats["mixed"],
            "discoverable_solutions": stats["discoverable"],
            "reachable_share": round(stats["discoverable"] / n, 3) if n else 0,
            "reachable_needing_discovery": stats["reachable_needing_discovery"],
            "reachable_mixed": stats["reachable_mixed"],
            "complete_under_web": stats["discoverable"] == n,
            "storages_in_answer": sorted(storages),
            "storages_needed": sorted(needed),
            "reviewer_storages_needed": len(needed & self.reviewers),
            "storages_reached_best_case": len(reached_any),
            "link_rounds": max_rounds,
            "seeds": seeds,
            "seed_fanout": len(set().union(*(self.seed_links(s) for s in seeds))) if seeds else 0,
        }
