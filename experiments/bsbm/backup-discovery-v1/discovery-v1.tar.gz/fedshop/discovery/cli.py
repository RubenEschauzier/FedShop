import json
import os
from pathlib import Path

import click

from . import links, reviewers, server, web, workload
from .common import DiscoveryConfig, LOGGER, choose_split, ensure_container, load_split
from .provenance import Analyzer, derivations


@click.group
def cli():
    """Discovery-based FedShop: split the federation, build and serve the web, build the workload."""


def _split(dconf, refresh=False):
    if refresh or not os.path.exists(dconf.path("split.json")):
        split = choose_split(dconf)
        split["reviewers"] = reviewers.find_reviewers(dconf) if dconf.reviewers_conf.get("enabled") else {}
        Path(dconf.path("split.json")).write_text(json.dumps(split, indent=2))
        chosen = links.choose_links(dconf, split)
        links.write_links(dconf.path("links.tsv"), chosen)
        LOGGER.info(f"Split batch {split['batch']}: {len(split['classical'])} classical, {len(split['discovered'])} discovered "
                    f"members, {len(split['reviewers'])} reviewer storages, {len(chosen)} links")
    return load_split(dconf)


def _links(dconf):
    return links.read_links(dconf.path("links.tsv"))


@cli.command()
@click.argument("configfile", type=click.Path(exists=True, dir_okay=False))
def split(configfile):
    """Choose the classical members, number the reviewers and draw the links (split.json, links.tsv)."""
    dconf = DiscoveryConfig(configfile)
    s = _split(dconf, refresh=True)
    click.echo(f"classical:  {' '.join(s['classical'])}\ndiscovered: {' '.join(s['discovered'])}\n"
               f"reviewers:  {len(s['reviewers'])} storages")


@cli.command("update-container")
@click.argument("configfile", type=click.Path(exists=True, dir_okay=False))
@click.option("--restore", is_flag=True, default=False, help="Undo both changes: FedShop's data as generated")
def update_container(configfile, restore):
    """Move reviewers into their own graphs and add the links, in the batch's Virtuoso container.

    Standard FedShop runs on that container (query generation, evaluation) need --restore first.
    """
    dconf = DiscoveryConfig(configfile)
    ensure_container(dconf)
    split = _split(dconf)
    state = reviewers.migrate(dconf, split, restore=restore)
    state["links"] = links.apply(dconf, _links(dconf), restore=restore)
    click.echo(json.dumps(state, indent=2))


@cli.command("build-web")
@click.argument("configfile", type=click.Path(exists=True, dir_okay=False))
def build_web(configfile):
    """Build storage documents (with their links) and storage roots, plus pages if enabled, into web.sqlite."""
    dconf = DiscoveryConfig(configfile)
    counts = web.build(dconf, _split(dconf), dconf.path("web.sqlite"), _links(dconf))
    click.echo(json.dumps(counts, indent=2))


@cli.command()
@click.argument("configfile", type=click.Path(exists=True, dir_okay=False))
@click.option("--port", type=click.INT, default=None, help="Defaults to discovery.web.port")
@click.option("--verbose", is_flag=True, default=False)
def serve(configfile, port, verbose):
    """Serve web.sqlite at the original FedShop IRIs."""
    dconf = DiscoveryConfig(configfile)
    server.run(port or int(dconf.web["port"]), dconf.path("web.sqlite"), dconf.web["storage_rel"],
               dconf.web["passthrough"], verbose)


@cli.command("build-workload")
@click.argument("configfile", type=click.Path(exists=True, dir_okay=False))
def build_workload(configfile):
    """Analyse FedShop's instances and the discovery templates, and write the selected workload."""
    dconf = DiscoveryConfig(configfile)
    records = workload.build(dconf, _split(dconf), dconf.path("web.sqlite"))
    selected = [r for r in records if r.get("selected")]
    click.echo(f"{len(selected)} instances selected, see {dconf.path('workload-summary.csv')}")


@cli.command()
@click.argument("configfile", type=click.Path(exists=True, dir_okay=False))
@click.argument("queryfile", type=click.Path(exists=True, dir_okay=False))
def check(configfile, queryfile):
    """Analyse one query over the split federation and print the result."""
    dconf = DiscoveryConfig(configfile)
    ensure_container(dconf)
    split = _split(dconf)
    reviewers.check_state(dconf, split, len(_links(dconf)))
    analyzer = Analyzer(split, web.load_holders(web.open_db(dconf.path("web.sqlite"), readonly=True)), dconf.pages,
                        links.adjacency(_links(dconf)))
    projection, patterns, rows = derivations(dconf.endpoint, Path(queryfile).read_text(), dconf.workload_conf["max_rows"])
    click.echo(json.dumps(analyzer.analyse(projection, patterns, rows), indent=2))


@cli.command("all")
@click.argument("configfile", type=click.Path(exists=True, dir_okay=False))
@click.pass_context
def all_steps(ctx, configfile):
    """split, update-container, build-web and build-workload in one go."""
    ctx.invoke(split, configfile=configfile)
    ctx.invoke(update_container, configfile=configfile, restore=False)
    ctx.invoke(build_web, configfile=configfile)
    ctx.invoke(build_workload, configfile=configfile)


if __name__ == "__main__":
    cli()
