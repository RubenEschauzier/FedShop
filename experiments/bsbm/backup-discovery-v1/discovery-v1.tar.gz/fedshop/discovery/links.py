"""Links between members' copies of the same global IRI: how members find each other without an index.

FedShop members share no data, only global BSBM IRIs: each member keeps a local copy of the
products, producers and features it deals with, `owl:sameAs` the global IRI. Here a copy also
links with `rdfs:seeAlso` to the copies at a few other members holding the same global IRI:

- a shop's copy links to review sites ("reviews"),
- a review site's copy links to shops ("where to buy") and, optionally, to other review sites
  ("also reviewed at");
- shops never link to other shops.

Each count is a number of peers per copy, or "all". Peers are drawn at random per copy (seeded), so
no member knows every holder and an engine may have to follow several copies to find them all.
No FedShop query uses rdfs:seeAlso, so the links change no answer. They are added to the documents
(web.py) and to the batch's Virtuoso container (`apply`), so documents and endpoints agree.
"""
import csv
import random
from collections import defaultdict

from .common import LOGGER, OWL_SAMEAS, global_kind, sparql_csv
from .reviewers import Renaming, _isql

SEEALSO = "http://www.w3.org/2000/01/rdf-schema#seeAlso"
DIRECTIONS = {  # (from kind, to kind) -> config key
    ("vendor", "ratingsite"): "reviews",
    ("ratingsite", "vendor"): "where_to_buy",
    ("ratingsite", "ratingsite"): "also_reviewed",
}


def _kind(member):
    return "vendor" if "vendor" in member else "ratingsite"


def collect_copies(dconf, split):
    """global IRI -> {member root: local copy IRI}, for the configured kinds."""
    kinds = set(dconf.links_conf["kinds"])
    renaming = Renaming(split)
    copies = defaultdict(dict)
    for name, member in sorted({**split["classical"], **split["discovered"]}.items()):
        for _, s, p, o in renaming.triples(dconf, name):
            if p[1:-1] == OWL_SAMEAS and o.startswith("<") and global_kind(o[1:-1]) in kinds:
                copies[o[1:-1]][member] = s[1:-1]
    return copies


def choose_links(dconf, split):
    """List of (global IRI, member, local copy, peer member, peer copy), deterministic."""
    conf = dconf.links_conf
    copies = collect_copies(dconf, split)
    links = []
    for g in sorted(copies):
        holders = copies[g]
        for member in sorted(holders):
            for (src, dst), key in DIRECTIONS.items():
                count = conf.get(key, 0)
                if src != _kind(member) or not count:
                    continue
                peers = sorted(m for m in holders if m != member and _kind(m) == dst)
                if count != "all":
                    rng = random.Random(f"{conf['seed']}|{key}|{g}|{member}")
                    peers = sorted(rng.sample(peers, min(int(count), len(peers))))
                links += [(g, member, holders[member], peer, holders[peer]) for peer in peers]
    return links


def write_links(path, links):
    with open(path, "w", newline="") as fs:
        writer = csv.writer(fs, delimiter="\t")
        writer.writerow(["global", "member", "local", "peer", "peer_local"])
        writer.writerows(links)


def read_links(path):
    with open(path, newline="") as fs:
        return [tuple(row) for row in list(csv.reader(fs, delimiter="\t"))[1:]]


def adjacency(links):
    """global IRI -> member -> set of peer members its copy links to."""
    adj = defaultdict(lambda: defaultdict(set))
    for g, member, _, peer, _ in links:
        adj[g][member].add(peer)
    return adj


def apply(dconf, links, restore=False, chunk=500):
    """Replace the seeAlso links in the container's member graphs (or remove them, with restore)."""
    members = sorted({**dconf.members}.values())
    statements = [f"SPARQL DELETE WHERE {{ GRAPH <{m}> {{ ?s <{SEEALSO}> ?o }} }};" for m in members]
    if not restore:
        by_member = defaultdict(list)
        for _, member, local, _, peer_local in links:
            by_member[member].append(f"<{local}> <{SEEALSO}> <{peer_local}> .")
        for member, triples in sorted(by_member.items()):
            for i in range(0, len(triples), chunk):
                statements.append(f"SPARQL INSERT DATA {{ GRAPH <{member}> {{ {' '.join(triples[i:i + chunk])} }} }};")
    _isql(dconf, statements)
    n = int(sparql_csv(dconf.endpoint, f"SELECT (COUNT(*) AS ?n) WHERE {{ GRAPH ?g {{ ?s <{SEEALSO}> ?o }} }}")[0]["n"])
    LOGGER.info(f"{dconf.container}: {n} seeAlso links")
    return n
