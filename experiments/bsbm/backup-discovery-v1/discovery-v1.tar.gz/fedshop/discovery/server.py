"""Serve the web of storages (every member and reviewer) at its original FedShop IRIs.

Requests can arrive in three forms, so any client can be pointed at it without rewriting IRIs:
- forward proxy:  GET http://www.vendor3.fr/Product12 HTTP/1.1   (curl -x, Java http.proxyHost)
- prefix proxy:   GET /http://www.vendor3.fr/Product12            (Comunica --httpProxy http://host:port/)
- Host header:    GET /Product12 with Host: www.vendor3.fr        (/etc/hosts or a DNS override)

Requests outside the web are passed through to local hosts only (`web.passthrough: local`, the
default), so clients can send all traffic, SPARQL endpoints included, through one proxy while the
benchmark never reaches the internet; `true` passes everything, `false` nothing. GET /_stats and /_reset on the server itself
report and reset request counters, like the FedShop proxy.
"""
import json
import threading
from collections import Counter
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlsplit

import requests

from .common import BSBM, LOGGER, member_root
from .web import open_db

TURTLE = "text/turtle; charset=utf-8"


class WebServer(ThreadingHTTPServer):
    daemon_threads = True
    # Engines open hundreds of connections at once; Python's default backlog of 5 makes the OS drop
    # them, and clients then stall on SYN retries or fail
    request_queue_size = 1024

    def __init__(self, port, dbfile, storage_rel, passthrough, verbose=False):
        super().__init__(("0.0.0.0", port), Handler)
        self.port = port
        self.dbfile = dbfile
        self.storage_rel = storage_rel
        self.passthrough = passthrough
        self.verbose = verbose
        self.local = threading.local()
        self.lock = threading.Lock()
        self.stats = Counter()
        info = json.loads(open_db(dbfile, readonly=True).execute("SELECT value FROM meta WHERE key='info'").fetchone()[0])
        split = info["split"]
        self.web_hosts = ({urlsplit(BSBM).netloc}
                          | {urlsplit(iri).netloc for part in ("classical", "discovered") for iri in split[part].values()}
                          | {urlsplit(r["root"]).netloc for r in (split.get("reviewers") or {}).values()})
        self.own_hosts = {f"localhost:{port}", f"127.0.0.1:{port}", f"0.0.0.0:{port}", ""}

    def db(self):
        if not hasattr(self.local, "db"):
            self.local.db = open_db(self.dbfile, readonly=True)
        return self.local.db

    def count(self, **kv):
        with self.lock:
            for k, v in kv.items():
                self.stats[k] += v


class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"
    server: WebServer

    def log_message(self, fmt, *args):
        if self.server.verbose:
            LOGGER.debug(fmt % args)

    def target(self):
        path = self.path
        if path.startswith(("http://", "https://")):
            return path, "forward"
        if path[1:].startswith(("http://", "https://")):
            return path[1:], "prefix"
        host = self.headers.get("Host", "")
        if host in self.server.own_hosts:
            return path, "own"
        return f"http://{host}{path}", "host"

    def reply(self, status, body=b"", ctype="text/plain; charset=utf-8", headers=None):
        self.send_response(status)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        for k, v in (headers or {}).items():
            self.send_header(k, v)
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(body)

    def handle_own(self, path):
        if path.startswith("/_stats"):
            with self.server.lock:
                body = json.dumps(dict(self.server.stats), indent=2).encode()
            return self.reply(200, body, "application/json")
        if path.startswith("/_reset"):
            with self.server.lock:
                self.server.stats.clear()
            return self.reply(200, b"reset\n")
        return self.reply(404, b"unknown path\n")

    def serve(self, body_in=None):
        url, mode = self.target()
        if mode == "own" or urlsplit(url).netloc in self.server.own_hosts:
            return self.handle_own(urlsplit(url).path if mode != "own" else url)

        parts = urlsplit(url)
        url = parts._replace(fragment="").geturl()
        if parts.netloc in self.server.web_hosts or member_root(f"{parts.scheme}://{parts.netloc}/"):
            if parts.path in ("", "/"):
                url = f"{parts.scheme}://{parts.netloc}/"
            row = self.server.db().execute("SELECT kind, member, body FROM docs WHERE url = ?", (url,)).fetchone()
            if row is None:
                self.server.count(requests=1, not_found=1)
                return self.reply(404, b"not part of the discoverable web\n")
            kind, member, body = row
            data = body.encode()
            headers = {}
            root = member or member_root(url)
            if root:
                headers["Link"] = f'<{root}>; rel="{self.server.storage_rel}"'
            self.server.count(requests=1, bytes=len(data), **{f"requests_{kind}": 1})
            return self.reply(200, data, TURTLE, headers)

        local = parts.hostname in ("localhost", "127.0.0.1")
        if mode == "host" or not self.server.passthrough or (self.server.passthrough == "local" and not local):
            self.server.count(outside_web=1)
            return self.reply(404, b"outside the discoverable web\n")
        headers = {k: v for k, v in self.headers.items() if k.lower() not in ("host", "proxy-connection", "connection", "content-length")}
        try:
            upstream = requests.request(self.command, url, data=body_in, headers=headers, timeout=600)
        except requests.RequestException as e:
            self.server.count(passthrough_errors=1)
            return self.reply(502, f"passthrough failed: {e}\n".encode())
        self.server.count(passthrough_requests=1, passthrough_bytes=len(upstream.content))
        return self.reply(upstream.status_code, upstream.content, upstream.headers.get("Content-Type", "application/octet-stream"))

    def do_GET(self):
        self.serve()

    def do_HEAD(self):
        self.serve()

    def do_POST(self):
        length = int(self.headers.get("Content-Length", 0) or 0)
        self.serve(self.rfile.read(length) if length else None)


def run(port, dbfile, storage_rel, passthrough, verbose=False):
    server = WebServer(port, dbfile, storage_rel, passthrough, verbose)
    LOGGER.info(f"Serving {dbfile} on http://localhost:{port}/ (forward proxy, prefix proxy or Host header)")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
