"""Build the discoverable part of the federation as a set of documents in one SQLite file.

Every member (classical ones included) and every reviewer (see reviewers.py) is a storage:
- one document per subject, at the subject's own IRI, including the subject's seeAlso links to
  other members' copies (see links.py);
- a storage root (the storage's namespace IRI) listing its documents with ldp:contains. A member's
  root also names the member's SPARQL endpoint; a reviewer's storage has no endpoint.
Classical members differ only in that the engine knows their endpoint up front.

Optionally (`pages.kinds`, off by default), a page per global BSBM IRI holds the backlink triples
`<local copy> owl:sameAs <global IRI>` of the members listed on it. That is an index, kept as a
baseline to compare the link-based web against.

Documents only contain triples that are in FedShop's data (after the reviewer renaming) or links,
apart from the storage roots, whose subject never occurs in the data.
"""
import json
import sqlite3
from collections import defaultdict
from pathlib import Path

from .common import LOGGER, OWL_SAMEAS, global_kind
from .links import SEEALSO
from .reviewers import Renaming

LDP = "http://www.w3.org/ns/ldp#"
PIM = "http://www.w3.org/ns/pim/space#"
VOID = "http://rdfs.org/ns/void#"
RDF_TYPE = "http://www.w3.org/1999/02/22-rdf-syntax-ns#type"


def open_db(path, readonly=False):
    if readonly:
        return sqlite3.connect(f"file:{path}?mode=ro", uri=True, check_same_thread=False)
    db = sqlite3.connect(path)
    db.executescript("""
        CREATE TABLE IF NOT EXISTS docs (url TEXT PRIMARY KEY, kind TEXT, member TEXT, body TEXT);
        CREATE TABLE IF NOT EXISTS holders (global TEXT, member TEXT, local TEXT);
        CREATE TABLE IF NOT EXISTS meta (key TEXT PRIMARY KEY, value TEXT);
    """)
    return db


def load_holders(db):
    holders = defaultdict(set)
    for g, m in db.execute("SELECT DISTINCT global, member FROM holders"):
        holders[g].add(m)
    return holders


def _root(root, docs, endpoint, endpoint_predicate):
    lines = [
        f"<{root}> <{RDF_TYPE}> <{LDP}Container> .",
        f"<{root}> <{RDF_TYPE}> <{LDP}BasicContainer> .",
        f"<{root}> <{RDF_TYPE}> <{PIM}Storage> .",
    ]
    if endpoint:
        lines += [
            f"<{root}> <{RDF_TYPE}> <{VOID}Dataset> .",
            f'<{root}> <{VOID}uriSpace> "{root}" .',
            f"<{root}> <{endpoint_predicate}> <{endpoint}> .",
        ]
    return "\n".join(lines + [f"<{root}> <{LDP}contains> <{url}> ." for url in sorted(docs)]) + "\n"


def build(dconf, split, outfile, links=()):
    Path(outfile).unlink(missing_ok=True)
    db = open_db(outfile)
    endpoints = dconf.member_endpoints()
    discovered = split["discovered"]
    listed = dict(discovered)
    if dconf.pages.get("include_classical"):
        listed.update(split["classical"])
    kinds = set(dconf.pages["kinds"])
    renaming = Renaming(split)
    reviewer_roots = {r["root"] for r in (split.get("reviewers") or {}).values()}
    backlinks = defaultdict(set)    # global IRI -> backlink triples for its page
    seealso = defaultdict(list)     # local copy -> its seeAlso triples
    for _, _, local, _, peer_local in links:
        seealso[local].append(f"<{local}> <{SEEALSO}> <{peer_local}> .")
    counts = defaultdict(int)

    # FedShop's .nq files repeat about a fifth of their quads; documents hold each triple once.
    for name, member in sorted({**split["classical"], **discovered}.items()):
        docs = defaultdict(lambda: defaultdict(dict))    # storage -> subject -> triples (ordered, deduplicated)
        holders = set()
        for root, s, p, o in renaming.triples(dconf, name):
            if p[1:-1] == OWL_SAMEAS and o.startswith("<") and global_kind(o[1:-1]):
                holders.add((o[1:-1], member, s[1:-1]))
                if name in listed and global_kind(o[1:-1]) in kinds:
                    backlinks[o[1:-1]].add(f"{s} {p} {o} .")
            docs[root][s[1:-1]][f"{s} {p} {o} ."] = None
        db.executemany("INSERT INTO holders VALUES (?, ?, ?)", sorted(holders))

        for root, storage_docs in docs.items():
            for url, lines in storage_docs.items():
                lines.update(dict.fromkeys(seealso.get(url, ())))
            db.executemany("INSERT INTO docs VALUES (?, 'doc', ?, ?)",
                           ((url, root, "\n".join(lines) + "\n") for url, lines in storage_docs.items()))
            kind = "reviewer" if root in reviewer_roots else "member"
            endpoint = endpoints[root] if kind == "member" else None
            db.execute("INSERT INTO docs VALUES (?, 'root', ?, ?)",
                       (root, root, _root(root, storage_docs, endpoint, dconf.web["endpoint_predicate"])))
            if kind == "member":
                kind = "discovered" if name in discovered else "classical"
            counts[f"storages_{kind}"] += 1
            counts[f"documents_{kind}"] += len(storage_docs)
        LOGGER.info(f"{name}: {len(docs.get(member, {}))} documents")

    for g, lines in backlinks.items():
        db.execute("INSERT INTO docs VALUES (?, 'page', NULL, ?)", (g, "\n".join(sorted(lines)) + "\n"))
        counts[f"pages_{global_kind(g)}"] += 1

    counts["links"] = len(links)
    db.execute("CREATE INDEX IF NOT EXISTS holders_global ON holders(global)")
    meta = {"split": split, "pages": dconf.pages, "web": dconf.web, "counts": dict(counts)}
    db.execute("INSERT INTO meta VALUES ('info', ?)", (json.dumps(meta),))
    db.commit()
    db.close()
    return dict(counts)
