"""Select the query instances of the discovery-based workload and write everything an engine needs.

Candidates are FedShop's generated instances plus instances of the templates in
experiments/bsbm/discovery/queries (constant `{{ProductXYZ}}`, chosen among products held by a
classical member and answering the template). Every candidate is analysed over the full federation (see provenance.py):

- FedShop instances are kept when at least one solution needs a discovered storage (a member or a
  reviewer) and is reachable through the links;
- template instances are kept when at least one reachable solution joins a classical member and a
  discovered storage ("hybrid-join").
Links reach only part of some answers: `reachable.csv` holds the reachable part of the reference
answer, and `reachable_share` its size relative to `results.csv`.
"""
import csv
import glob
import io
import json
import random
import re
import shutil
from pathlib import Path

from .common import LOGGER, ensure_container, global_kind, sparql_csv, sparql_raw_csv
from .provenance import Analyzer, derivations
from .links import adjacency, read_links
from .reviewers import check_state
from .web import load_holders, open_db

FIELDS = ["query", "instance", "source", "selected", "category", "solutions", "derivations",
          "classical_only_solutions", "solutions_needing_discovery", "solutions_needing_reviewers", "mixed_solutions",
          "discoverable_solutions", "reachable_share", "reachable_needing_discovery", "reachable_mixed", "complete_under_web", "storages_needed", "reviewer_storages_needed",
          "storages_reached_best_case", "link_rounds", "seed_fanout", "seeds", "storages_in_answer",
          "reference_rows", "error"]


def analyse(dconf, analyzer, query):
    """Analysis record plus the projection keys of the reachable solutions."""
    try:
        projection, patterns, rows = derivations(dconf.endpoint, query, dconf.workload_conf["max_rows"])
    except OverflowError as e:
        return {"category": "too-large", "error": str(e)}, (None, set())
    return analyzer.analyse(projection, patterns, rows), (projection, set(analyzer.reachable))


def write_instance(outdir, query_text, record, dconf, reachable):
    Path(outdir).mkdir(parents=True, exist_ok=True)
    Path(outdir, "injected.sparql").write_text(query_text)
    reference = sparql_raw_csv(dconf.endpoint, query_text)
    Path(outdir, "results.csv").write_text(reference)
    projection, keys = reachable
    rows = list(csv.reader(io.StringIO(reference)))
    header = rows[0] if rows else []
    with open(Path(outdir, "reachable.csv"), "w", newline="") as fs:
        writer = csv.writer(fs)
        writer.writerow(header)
        writer.writerows(r for r in rows[1:] if tuple(dict(zip(header, r)).get(v, "") for v in projection) in keys)
    Path(outdir, "seeds.txt").write_text("".join(f"{s}\n" for s in record["seeds"]))
    Path(outdir, "analysis.json").write_text(json.dumps(record, indent=2))
    return max(len(reference.strip().splitlines()) - 1, 0)


def write_sources(dconf, split, outdir):
    endpoints = dconf.member_endpoints()
    Path(outdir).mkdir(parents=True, exist_ok=True)
    with open(Path(outdir, "classical-endpoints.tsv"), "w") as fs:
        for name, iri in split["classical"].items():
            fs.write(f"{name}\t{iri}\t{endpoints[iri]}\n")
    with open(Path(outdir, "classical-fedx.ttl"), "w") as fs:
        fs.write("@prefix sd: <http://www.w3.org/ns/sparql-service-description#> .\n"
                 "@prefix fedx: <http://rdf4j.org/config/federation#> .\n\n")
        for iri in split["classical"].values():
            fs.write(f'<{iri}> a sd:Service ;\n    fedx:store "SPARQLEndpoint";\n'
                     f'    sd:endpoint "{endpoints[iri]}";\n    fedx:supportsASKQueries true .\n\n')
    with open(Path(outdir, "storage-roots.txt"), "w") as fs:  # discovered storages, for analysis only
        fs.writelines(f"{iri}\n" for iri in split["discovered"].values())
        fs.writelines(f"{r['root']}\n" for r in (split.get("reviewers") or {}).values())


def answered_anchors(dconf, template, anchors):
    """Anchors for which the template has at least one answer (all anchors if that query fails)."""
    query = re.sub(r"SELECT\s+(DISTINCT\s+)?.*?\s+WHERE", "SELECT DISTINCT ?ProductXYZ WHERE",
                   template.replace("{{ProductXYZ}}", "?ProductXYZ"), count=1, flags=re.S | re.I)
    try:
        answered = {row["ProductXYZ"] for row in sparql_csv(dconf.endpoint, query)}
    except Exception as e:
        LOGGER.warning(f"Could not pre-select anchors ({e}), sampling among all of them")
        return anchors
    return [a for a in anchors if a in answered]


def build(dconf, split, dbfile):
    ensure_container(dconf)
    link_list = read_links(dconf.path("links.tsv"))
    check_state(dconf, split, len(link_list))
    db = open_db(dbfile, readonly=True)
    holders = load_holders(db)
    analyzer = Analyzer(split, holders, dconf.pages, adjacency(link_list))
    conf = dconf.workload_conf
    outdir = Path(dconf.outdir, "workload")
    shutil.rmtree(outdir, ignore_errors=True)
    records = []

    # FedShop's own instances
    for path in sorted(glob.glob(f"{dconf.generation_dir}/q*/instance_*/injected.sparql")):
        query, instance = Path(path).parts[-3], int(Path(path).parts[-2].split("_")[1])
        text = Path(path).read_text()
        result, reachable = analyse(dconf, analyzer, text)
        record = {"query": query, "instance": instance, "source": "fedshop", **result}
        record["selected"] = record.get("reachable_needing_discovery", 0) > 0
        if record["selected"]:
            record["reference_rows"] = write_instance(outdir / query / f"instance_{instance}", text, record, dconf, reachable)
        records.append(record)
        LOGGER.info(f"{query}#{instance}: {record['category']}{' (selected)' if record['selected'] else ''}")

    # New templates anchored at a product held by a classical member
    classical = set(split["classical"].values())
    anchors = sorted(g for g, ms in holders.items() if global_kind(g) == "Product" and ms & classical)
    for tpl in sorted(glob.glob(f"{conf['templates_dir']}/*.sparql")):
        query = Path(tpl).stem
        template = Path(tpl).read_text()
        rng = random.Random(f"{conf['seed']}-{query}")
        answered = answered_anchors(dconf, template, anchors)
        candidates = rng.sample(answered, min(conf["max_candidates"], len(answered)))
        kept = tried = 0
        for anchor in candidates:
            if kept == conf["per_template"]:
                break
            tried += 1
            text = template.replace("{{ProductXYZ}}", f"<{anchor}>")
            record, reachable = analyse(dconf, analyzer, text)
            if record.get("reachable_mixed", 0) > 0:
                record = {"query": query, "instance": kept, "source": "template", "selected": True, "anchor": anchor, **record}
                record["reference_rows"] = write_instance(outdir / query / f"instance_{kept}", text, record, dconf, reachable)
                records.append(record)
                kept += 1
        LOGGER.info(f"{query}: kept {kept}/{conf['per_template']} hybrid-join instances after {tried} candidates")
        records.append({"query": query, "instance": -1, "source": "template-search", "selected": False,
                        "category": f"kept {kept} of {tried} candidates"})

    write_sources(dconf, split, Path(dconf.outdir, "sources"))
    with open(Path(dconf.outdir, "workload-summary.csv"), "w", newline="") as fs:
        writer = csv.DictWriter(fs, fieldnames=FIELDS, extrasaction="ignore")
        writer.writeheader()
        for r in records:
            row = dict(r)
            for k in ("storages_needed", "seeds", "storages_in_answer"):
                if isinstance(row.get(k), list):
                    row[k] = " ".join(re.sub(r"^http://www\.|\.fr/$", "", m) for m in row[k])
            writer.writerow(row)
    return records
