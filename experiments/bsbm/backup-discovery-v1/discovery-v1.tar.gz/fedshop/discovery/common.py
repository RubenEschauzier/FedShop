import csv
import io
import json
import os
import random
import re
import subprocess
import time
from pathlib import Path

import requests
from omegaconf import OmegaConf

from ..utils import docker_check_container_running, fedshop_logger, load_config, ping

LOGGER = fedshop_logger(Path(__file__).name)

BSBM = "http://www4.wiwiss.fu-berlin.de/bizer/bsbm/v01/vocabulary/"
OWL_SAMEAS = "http://www.w3.org/2002/07/owl#sameAs"
GLOBAL_IRI = re.compile(r"^" + re.escape(BSBM) + r"(Product|ProductType|ProductFeature|Producer)\d+$")
MEMBER_IRI = re.compile(r"^(http://www\.(vendor|ratingsite|reviewer)\d+\.fr/)")
NQUAD = re.compile(r"^(<[^>]*>)\s+(<[^>]*>)\s+(.*?)\s+(<[^>]*>)\s*\.\s*$")

DEFAULTS = {
    "batch": None,                       # federation used for the variant; default: last batch
    "classical": {"ratio": 0.5, "seed": 42, "members": None},
    "reviewers": {"enabled": True},      # every reviewer in a discoverable storage of their own
    # seeAlso links between copies of the same global IRI, as peers per copy (a number or "all")
    "links": {"kinds": ["Product", "Producer", "ProductFeature"], "where_to_buy": 3, "reviews": 2,
              "also_reviewed": 0, "seed": 42},
    # global IRI pages listing every holder: an index, kept only as a baseline (off by default)
    "pages": {"kinds": [], "include_classical": False},
    "web": {
        "port": 8899,
        "endpoint_predicate": "http://rdfs.org/ns/void#sparqlEndpoint",
        "storage_rel": "http://www.w3.org/ns/pim/space#storage",
        "passthrough": "local",           # local: only local hosts (the endpoints); true: anything; false: nothing
    },
    "workload": {"templates_dir": None, "per_template": 5, "max_candidates": 200, "max_rows": 100000, "seed": 42},
}


def global_kind(iri):
    """Return the kind of a global BSBM IRI (Product, ProductFeature, ...), or None."""
    m = GLOBAL_IRI.match(iri)
    return m.group(1) if m else None


def member_root(iri):
    """Return the storage root (member or reviewer namespace) of a local IRI, or None."""
    m = MEMBER_IRI.match(iri)
    return m.group(1) if m else None


class DiscoveryConfig:
    """FedShop config plus the `discovery` section, with defaults filled in."""

    def __init__(self, configfile):
        self.configfile = configfile
        self.conf = load_config(configfile)
        gen = self.conf["generation"]
        section = self.conf.get("discovery")
        section = OmegaConf.to_container(section, resolve=True) if section is not None else {}

        def merged(key):
            value = dict(DEFAULTS[key]) if isinstance(DEFAULTS[key], dict) else DEFAULTS[key]
            if key in section and section[key] is not None:
                if isinstance(value, dict):
                    value.update({k: v for k, v in dict(section[key]).items()})
                else:
                    value = section[key]
            return value

        self.workdir = gen["workdir"]
        self.n_batch = int(gen["n_batch"])
        batch = merged("batch")
        self.batch = self.n_batch - 1 if batch is None else int(batch)
        self.classical_conf = merged("classical")
        self.reviewers_conf = merged("reviewers")
        self.links_conf = merged("links")
        self.pages = merged("pages")
        self.web = merged("web")
        self.workload_conf = merged("workload")
        self.outdir = section.get("workdir") or f"{self.workdir}/benchmark/discovery"
        if self.workload_conf.get("templates_dir") is None:
            self.workload_conf["templates_dir"] = f"{self.workdir}/discovery/queries"

        virtuoso = gen["virtuoso"]
        self.data_dir = virtuoso["data_dir"]
        self.endpoint = virtuoso["default_endpoint"]
        self.compose_file = virtuoso["compose_file"]
        self.service_name = virtuoso["service_name"]
        self.members = dict(virtuoso["federation_members"][f"batch{self.batch}"])  # name -> namespace IRI
        self.generation_dir = f"{self.workdir}/benchmark/generation"

    @property
    def container(self):
        return f"docker-{self.service_name}-{self.batch + 1}"

    def member_endpoints(self):
        """Namespace IRI -> member SPARQL endpoint, as registered by the ingestion of this batch."""
        mapping_file = f"{self.workdir}/virtuoso-proxy-mapping-batch{self.batch}.json"
        with open(mapping_file) as fs:
            mapping = json.load(fs)
        return {iri: mapping[iri] for iri in self.members.values()}

    def path(self, *parts):
        p = Path(self.outdir, *parts)
        p.parent.mkdir(parents=True, exist_ok=True)
        return str(p)


def choose_split(dconf):
    """Pick the classical members. Stratified over vendors and rating sites so both kinds stay mixed."""
    explicit = dconf.classical_conf.get("members")
    names = sorted(dconf.members, key=lambda n: (re.sub(r"\d+", "", n), int(re.sub(r"\D", "", n))))
    if explicit:
        classical = [n for n in names if n in set(explicit)]
    else:
        rng = random.Random(dconf.classical_conf.get("seed", 42))
        ratio = float(dconf.classical_conf.get("ratio", 0.5))
        classical = []
        for kind in ("vendor", "ratingsite"):
            group = [n for n in names if re.sub(r"\d+", "", n) == kind]
            classical += rng.sample(group, round(ratio * len(group)))
    classical = sorted(set(classical), key=names.index)
    discovered = [n for n in names if n not in set(classical)]
    return {
        "batch": dconf.batch,
        "classical": {n: dconf.members[n] for n in classical},
        "discovered": {n: dconf.members[n] for n in discovered},
    }


def load_split(dconf):
    with open(dconf.path("split.json")) as fs:
        return json.load(fs)


def read_member_triples(dconf, name):
    """Yield (s, p, o) N-Triples terms of one member's dataset file."""
    with open(os.path.join(dconf.data_dir, f"{name}.nq")) as fs:
        for line in fs:
            m = NQUAD.match(line)
            if m:
                yield m.group(1), m.group(2), m.group(3)


def ensure_container(dconf):
    """Make sure the Virtuoso container holding the variant's federation is the one running."""
    if not docker_check_container_running(dconf.container):
        LOGGER.info(f"Starting {dconf.container}...")
        subprocess.run(f"docker compose -f {dconf.compose_file} stop", shell=True, check=True)
        subprocess.run(f"docker start {dconf.container}", shell=True, check=True)
    while not ping(dconf.endpoint):
        LOGGER.debug(f"Waiting for {dconf.endpoint}...")
        time.sleep(1)


def sparql_csv(endpoint, query, timeout=300):
    """Run a SELECT query and return its rows as dicts (IRIs without brackets)."""
    r = requests.post(endpoint, data={"query": query}, headers={"Accept": "text/csv"}, timeout=timeout)
    if r.status_code != 200:
        raise RuntimeError(f"SPARQL error {r.status_code}: {r.text[:500]}")
    return list(csv.DictReader(io.StringIO(r.text)))


def sparql_raw_csv(endpoint, query, timeout=300):
    r = requests.post(endpoint, data={"query": query}, headers={"Accept": "text/csv"}, timeout=timeout)
    if r.status_code != 200:
        raise RuntimeError(f"SPARQL error {r.status_code}: {r.text[:500]}")
    return r.text
