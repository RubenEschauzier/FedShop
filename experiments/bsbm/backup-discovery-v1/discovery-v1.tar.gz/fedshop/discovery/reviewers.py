"""Reviewers as discoverable personal storages.

FedShop keeps each reviewer (bsbm:Person) inside the rating site that published their reviews.
Here every reviewer gets a storage of their own, whatever side of the split their rating site is on:

- the reviewer's IRI moves from the rating site to the storage (`http://www.ratingsite0.fr/Person2`
  becomes `http://www.reviewer2.fr/me`), and the profile triples move with it;
- the reviews stay at the rating site, and their `rev:reviewer` triples point at the new IRI. That
  triple is the only way to a reviewer, so a query that needs a reviewer's profile always crosses
  from a rating site into a discovered storage.

Reviewer storages are plain documents without a SPARQL endpoint.

The same renaming is applied to the documents (web.py) and to the Virtuoso container of the
variant's batch (`migrate`), where each storage becomes its own named graph. That way the
provenance analysis and the reference results see the same data as an engine, and the rating
sites' endpoints no longer answer for their reviewers. `migrate(restore=True)` undoes it.
"""
import re
import subprocess

from .common import BSBM, LOGGER, read_member_triples, sparql_csv

RDF_TYPE = "http://www.w3.org/1999/02/22-rdf-syntax-ns#type"
PERSON = BSBM + "Person"
ISQL = "/opt/virtuoso-opensource/bin/isql"


def find_reviewers(dconf):
    """name -> {root, iri, site, original}, numbered by rating site, then person.

    Rating sites of a batch are a prefix of the next batch's, so numbers are stable across batches.
    """
    sites = sorted((n for n in dconf.members if n.startswith("ratingsite")), key=lambda n: int(re.sub(r"\D", "", n)))
    reviewers = {}
    for site in sites:
        persons = {s[1:-1] for s, p, o in read_member_triples(dconf, site)
                   if p == f"<{RDF_TYPE}>" and o == f"<{PERSON}>"}
        for original in sorted(persons, key=lambda iri: int(re.sub(r"\D", "", iri.rsplit("/", 1)[1]))):
            k = len(reviewers)
            root = f"http://www.reviewer{k}.fr/"
            reviewers[f"reviewer{k}"] = {"root": root, "iri": f"{root}me", "site": site, "original": original}
    return reviewers


class Renaming:
    """Applies the reviewer renaming to N-Triples terms and tells which storage a subject lives in."""

    def __init__(self, split):
        reviewers = split.get("reviewers") or {}
        self.terms = {f"<{r['original']}>": f"<{r['iri']}>" for r in reviewers.values()}
        self.roots = {f"<{r['iri']}>": r["root"] for r in reviewers.values()}

    def triples(self, dconf, name):
        """Yield (storage root, s, p, o) for one member's dataset file, after renaming."""
        member = dconf.members[name]
        for s, p, o in read_member_triples(dconf, name):
            s, o = self.terms.get(s, s), self.terms.get(o, o)
            yield self.roots.get(s, member), s, p, o


def _isql(dconf, statements):
    script = "\n".join(statements) + "\ncheckpoint;\n"
    proc = subprocess.run(["docker", "exec", "-i", dconf.container, ISQL, "1111", "dba", "dba"],
                          input=script, text=True, capture_output=True)
    if proc.returncode != 0 or "*** Error" in proc.stdout + proc.stderr:
        raise RuntimeError(f"isql failed: {(proc.stdout + proc.stderr)[-2000:]}")


def migrate(dconf, split, restore=False):
    """Move reviewer profiles into their own named graphs (or back, with restore). Idempotent."""
    statements = []
    for r in (split.get("reviewers") or {}).values():
        site = dconf.members[r["site"]]
        old, new = (r["iri"], r["original"]) if restore else (r["original"], r["iri"])
        src, dst = (r["root"], site) if restore else (site, r["root"])
        statements.append(f"SPARQL DELETE {{ GRAPH <{src}> {{ <{old}> ?p ?o }} }} "
                          f"INSERT {{ GRAPH <{dst}> {{ <{new}> ?p ?o }} }} WHERE {{ GRAPH <{src}> {{ <{old}> ?p ?o }} }};")
        statements.append(f"SPARQL DELETE {{ GRAPH <{site}> {{ ?s ?p <{old}> }} }} "
                          f"INSERT {{ GRAPH <{site}> {{ ?s ?p <{new}> }} }} WHERE {{ GRAPH <{site}> {{ ?s ?p <{old}> }} }};")
    if statements:
        _isql(dconf, statements)
    return status(dconf)


def status(dconf):
    """Triples currently in reviewer graphs, and reviewer profiles still inside rating sites."""
    moved = sparql_csv(dconf.endpoint, 'SELECT (COUNT(*) AS ?n) WHERE { GRAPH ?g { ?s ?p ?o } '
                                       'FILTER(STRSTARTS(STR(?g), "http://www.reviewer")) }')[0]["n"]
    left = sparql_csv(dconf.endpoint, f'SELECT (COUNT(*) AS ?n) WHERE {{ GRAPH ?g {{ ?s a <{PERSON}> }} '
                                      'FILTER(STRSTARTS(STR(?g), "http://www.ratingsite")) }')[0]["n"]
    LOGGER.info(f"{dconf.container}: {moved} triples in reviewer storages, {left} reviewers left in rating sites")
    return {"reviewer_triples": int(moved), "reviewers_in_rating_sites": int(left)}


def check_state(dconf, split, n_links=None):
    """Refuse to analyse when the container disagrees with split.json / links.tsv."""
    state = status(dconf)
    if n_links is not None:
        seealso = "http://www.w3.org/2000/01/rdf-schema#seeAlso"
        n = int(sparql_csv(dconf.endpoint, f"SELECT (COUNT(*) AS ?n) WHERE {{ GRAPH ?g {{ ?s <{seealso}> ?o }} }}")[0]["n"])
        if n != n_links:
            raise RuntimeError(f"{dconf.container} has {n} links, links.tsv has {n_links}: run `fedshop-discovery update-container`")
    if split.get("reviewers") and state["reviewers_in_rating_sites"] > 0:
        raise RuntimeError(f"{dconf.container} still has reviewers inside rating sites: run `fedshop-discovery update-container`")
    if not split.get("reviewers") and state["reviewer_triples"] > 0:
        raise RuntimeError(f"{dconf.container} has reviewer storages but the split has none: run `update-container --restore` "
                           "with the split that moved them, or enable discovery.reviewers")
